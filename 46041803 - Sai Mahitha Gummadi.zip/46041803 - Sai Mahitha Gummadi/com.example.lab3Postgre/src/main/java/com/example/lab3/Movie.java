package com.example.lab3;

import javax.persistence.Column;

import javax.persistence.Entity;

import javax.persistence.Id;

import javax.persistence.Table;

@Entity

@Table

public class Movie {

	@Id

	@Column

	private int mid;

	@Column

	private String name;

	@Column

	private double ticket;

	public int getMid() {

		return mid;

	}

	public void setMid(int mid) {

		this.mid = mid;

	}

	public String getName() {

		return name;

	}

	public void setName(String name) {

		this.name = name;

	}

	public double getTicket() {

		return ticket;

	}

	public void setTicket(double ticket) {

		this.ticket = ticket;

	}

}

package com.example.lab3;
import java.util.ArrayList;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

@Service

public class MovieService {

	@Autowired

	MovieRepository movieRepository;

	public List<Movie> getAllMovie() {

		List<Movie> movie = new ArrayList<Movie>();

		movieRepository.findAll().forEach(movie1 -> movie.add(movie1));

		return movie;

	}



	public void saveOrUpdate(Movie movie) {

		movieRepository.save(movie);

	}

	public void delete(int id) {

		movieRepository.deleteById(id);

	}

	public void update(Movie movie, int mid) {

		movieRepository.save(movie);

	}

}